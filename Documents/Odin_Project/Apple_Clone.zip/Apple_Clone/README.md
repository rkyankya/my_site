# micro-apple
Microverse Project

Backgrounds and Gradients.

This project is to learn how to apply backgrounds and gradients with HTML and CSS.

The task was to copy apple's old website apple website

The source of the project is <https://www.theodinproject.com/courses/html5-and-css3/lessons/building-with-backgrounds-and-gradients>

Author
This project was executed by Kyankya Raymond a student of Microverse.

Technologies Used.
HTML and CSS

Setup
How to setup a repo of this page on your local machine:

Open your git bash and cd to the location you'd like to put your files the run the command below.

Git clone: git clone <https://github.com/rkyankya/Apple_Clone.git>
