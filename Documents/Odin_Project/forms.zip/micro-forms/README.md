# HTML Forms
Microverse project

This project consists of building an HTML document that matches the appearance of mint.com’s signup page.

You can find the original project specification at:
 <https://www.theodinproject.com/courses/html5-and-css3/lessons/html-forms>  
<https://www.theodinproject.com/courses/html5-and-css3/lessons/embedding-images-and-video>

Author:
This project was executed by Mark Baidebura and Kyankya Raymond students of Microverse.

Technologies Used.
HTML and CSS

Setup
How to setup a repo of this page on your local machine:

Open your git bash and cd to the location you'd like to put your files the run the command below.

Git clone: git clone <https://github.com/webmarkyn/micro-forms.git>

Here is the link to the live version of this project here
